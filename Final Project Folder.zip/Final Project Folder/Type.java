public class Type
{
   public String name;
   public String url;
}