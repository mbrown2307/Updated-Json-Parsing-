public class Types
{
   public int slot;
   public Type type;
}